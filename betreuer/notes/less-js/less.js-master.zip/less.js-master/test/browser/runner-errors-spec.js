describe("less.js error tests", function() {
    testLessErrorsInDocument();
});
